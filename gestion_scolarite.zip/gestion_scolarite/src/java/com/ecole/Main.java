package com.ecole;

import com.ecole.dao.*;
import com.ecole.model.*;
import java.sql.*;
import java.util.Scanner;

/**
 * Classe principale : point d'entrée du programme.
 * - Demande les identifiants MySQL via la console.
 * - Initialise la connexion JDBC avec DatabaseConnection.init().
 * - Vérifie que l'utilisateur est bien 'gestion_user' avec les bons privilèges.
 * - Propose un menu interactif pour gérer étudiants, cours et inscriptions.
 */
public class Main 
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // === Étape 1 : Connexion à la base ===
        System.out.println("=== Connexion à la base MySQL ===");

        System.out.print("URL JDBC (par défaut: jdbc:mysql://localhost:3306/gestion_scolarite): ");
        String url = sc.nextLine().trim();
        if (url.isEmpty()) {
            url = "jdbc:mysql://localhost:3306/gestion_scolarite?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true";
        }

        System.out.print("Utilisateur MySQL: ");
        String user = sc.nextLine().trim();

        System.out.print("Mot de passe MySQL: ");
        String password = sc.nextLine().trim();

        // Initialiser la configuration de connexion
        DatabaseConnection.init(url, user, password);

        // Tenter la connexion réelle
        Connection conn;
        try {
            conn = DatabaseConnection.getConnection();
            System.out.println("✅ Connexion réussie.");
        } catch (SQLException e) {
            System.out.println("❌ Connexion échouée. Programme arrêté.");
            sc.close();
            return; // pas de menu si connexion échouée
        }

        // === Étape 2 : Vérification stricte de l'utilisateur ===
        if (!"gestion_user".equals(user)) {
            System.out.println("❌ Seul l'utilisateur 'gestion_user' est autorisé à gérer la scolarité.");
            fermer(conn);
            sc.close();
            return;
        }

        // === Étape 3 : Vérification des privilèges sur gestion_scolarite ===
        boolean accesGestion = false;
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SHOW GRANTS FOR CURRENT_USER")) {
            while (rs.next()) {
                String grant = rs.getString(1);
                if (grant.contains("gestion_scolarite") &&
                    (grant.contains("SELECT") || grant.contains("INSERT") ||
                     grant.contains("UPDATE") || grant.contains("DELETE"))) {
                    accesGestion = true;
                }
            }
        } catch (SQLException e) {
            System.out.println("❌ Erreur lors de la vérification des privilèges: " + e.getMessage());
            fermer(conn);
            sc.close();
            return;
        }

        if (!accesGestion) {
            System.out.println("❌ Vous êtes connecté, mais vous n'avez pas les droits nécessaires sur 'gestion_scolarite'.");
            fermer(conn);
            sc.close();
            return;
        }

        System.out.println("✅ Accès confirmé : vous pouvez gérer la scolarité.");

        // === Étape 4 : Initialisation des DAO ===
        EtudiantDAO etudiantDAO = new EtudiantDAO();
        CoursDAO coursDAO = new CoursDAO();
        InscriptionDAO inscriptionDAO = new InscriptionDAO();

        // === Étape 5 : Boucle du menu principal ===
        while (true) {
            System.out.println("=== Menu Gestion Scolarité ===");
            System.out.println("1. Ajouter un étudiant");
            System.out.println("2. Lister les étudiants");
            System.out.println("3. Ajouter un cours");
            System.out.println("4. Lister les cours");
            System.out.println("5. Inscrire un étudiant à un cours");
            System.out.println("6. Gestion des inscriptions");
            System.out.println("7. Mettre à jour un étudiant");
            System.out.println("8. Supprimer un étudiant");
            System.out.println("0. Quitter");

            System.out.print("Votre choix: ");
            int choix;
            try {
                choix = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Choix invalide. Entrez un nombre.");
                continue;
            }

            switch (choix) {
                case 1:
                    System.out.print("Nom: ");
                    String nom = sc.nextLine().trim();
                    System.out.print("Prénom: ");
                    String prenom = sc.nextLine().trim();
                    System.out.print("Date de naissance (YYYY-MM-DD): ");
                    String dateNaissance = sc.nextLine().trim();
                    Etudiant e = new Etudiant(0, nom, prenom, dateNaissance);
                    etudiantDAO.ajouterEtudiant(e);
                    System.out.println("✅ Étudiant ajouté : " + nom + " " + prenom);
                    break;

                case 2:
                    System.out.println("--- Liste des étudiants ---");
                    System.out.printf("%-5s %-20s %-20s %-15s%n", "ID", "Nom", "Prénom", "Date de naissance");

                    for (Etudiant et : etudiantDAO.listerEtudiants()) {
                        System.out.printf("%-5d %-20s %-20s %-15s%n",
                            et.getId(),
                            et.getNom(),
                            et.getPrenom(),
                            et.getDateNaissance() != null ? et.getDateNaissance() : "N/A");
                    }
                    break;

                case 3:
                    System.out.print("Nom du cours: ");
                    String nomCours = sc.nextLine().trim();
                    System.out.print("Crédits (entier): ");
                    int credits;
                    try {
                        credits = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Valeur de crédits invalide.");
                        break;
                    }
                    Cours c = new Cours(0, nomCours, credits);
                    coursDAO.ajouterCours(c);
                    System.out.println("✅ Cours ajouté : " + nomCours + " (" + credits + " crédits)");
                    break;

                case 4:
                    System.out.println("--- Liste des cours ---");
                    System.out.printf("%-5s %-30s %-10s%n", "ID", "Nom du cours", "Crédits");
                    for (Cours cours : coursDAO.listerCours()) {
                        System.out.printf("%-5d %-30s %-10d%n",
                            cours.getId(),
                            cours.getNomCours(),
                            cours.getCredits()
                        );
                    }
                    break;

                case 5:
                    System.out.println("--- Inscrire un étudiant à un cours ---");
                    System.out.print("ID étudiant: ");
                    int etudiantId;
                    try {
                        etudiantId = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("ID étudiant invalide.");
                        break;
                    }

                    System.out.print("ID cours: ");
                    int coursId;
                    try {
                        coursId = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("ID cours invalide.");
                        break;
                    }

                    // Vérification existence étudiant
                    if (!etudiantDAO.existeEtudiant(etudiantId)) {
                        System.out.println("❌ Aucun étudiant avec l’ID " + etudiantId);
                        break;
                    }

                    // Vérification existence cours
                    if (!coursDAO.existeCours(coursId)) {
                        System.out.println("❌ Aucun cours avec l’ID " + coursId);
                        break;
                    }

                    // Si tout est bon, on inscrit
                    Inscription ins = new Inscription(etudiantId, coursId);
                    boolean ajout = inscriptionDAO.ajouterInscription(ins);

                    if (ajout) {
                        System.out.println("✅ Inscription ajoutée : Étudiant " + etudiantId + " → Cours " + coursId);
                    } else {
                        System.out.println("ℹ️ L’inscription existe déjà ou une erreur est survenue.");
                    }
                    break;

                case 6:
                    System.out.println("=== Gestion des inscriptions ===");
                    System.out.println("1. Voir toutes les inscriptions");
                    System.out.println("2. Voir les étudiants inscrits à un cours donné");
                    System.out.print("Choix : ");
                    int sousChoix;
                    try {
                        sousChoix = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("Choix invalide.");
                        break;
                    }

                    if (sousChoix == 1) {
                        System.out.println("--- Liste des inscriptions ---");
                        // Affichage aligné pour cohérence visuelle
                        System.out.printf("%-5s %-10s %-20s %-20s %-10s %-30s%n",
                            "ID", "ID Étud.", "Nom", "Prénom", "ID Cours", "Nom du cours");

                        for (Inscription insc : inscriptionDAO.listerInscriptions()) {
                            System.out.printf("%-5d %-10d %-20s %-20s %-10d %-30s%n",
                                insc.getIdInscription(),
                                insc.getEtudiantId(),
                                insc.getNomEtudiant(),
                                insc.getPrenomEtudiant(),
                                insc.getCoursId(),
                                insc.getNomCours()
                            );
                        }

                    } else if (sousChoix == 2) {
                        System.out.print("ID du cours à consulter : ");
                        int idCours;
                        try {
                            idCours = Integer.parseInt(sc.nextLine().trim());
                        } catch (NumberFormatException ex) {
                            System.out.println("ID invalide.");
                            break;
                        }

                        System.out.println("--- Étudiants inscrits au cours ID " + idCours + " ---");
                        System.out.printf("%-5s %-20s %-20s %-15s %-30s%n",
                            "ID Étud.", "Nom", "Prénom", "Naissance", "Cours");

                        for (Inscription insc : inscriptionDAO.listerEtudiantsParCours(idCours)) {
                            System.out.printf("%-5d %-20s %-20s %-15s %-30s%n",
                                insc.getEtudiantId(),
                                insc.getNomEtudiant(),
                                insc.getPrenomEtudiant(),
                                insc.getDateNaissance() != null ? insc.getDateNaissance().toString() : "N/A",
                                insc.getNomCours()
                            );
                        }

                    } else {
                        System.out.println("Choix invalide.");
                    }
                    break;

                case 7:
                    System.out.println("--- Mettre à jour un étudiant ---");
                    System.out.print("ID de l’étudiant à modifier : ");
                    int idModif;
                    try {
                        idModif = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("ID invalide.");
                        break;
                    }

                    if (!etudiantDAO.existeEtudiant(idModif)) {
                        System.out.println("❌ Aucun étudiant avec l’ID " + idModif);
                        break;
                    }

                    System.out.print("Nouveau nom : ");
                    String nouveauNom = sc.nextLine().trim();
                    System.out.print("Nouveau prénom : ");
                    String nouveauPrenom = sc.nextLine().trim();
                    System.out.print("Nouvelle date de naissance (YYYY-MM-DD) : ");
                    String nouvelleDateNaissance = sc.nextLine().trim();

                    boolean modifie = etudiantDAO.mettreAJourEtudiant(idModif, nouveauNom, nouveauPrenom, nouvelleDateNaissance);
                    if (modifie) {
                        System.out.println("✅ Étudiant mis à jour.");
                    } else {
                        System.out.println("❌ Échec de la mise à jour.");
                    }
                    break;

                case 8:
                    System.out.println("--- Supprimer un étudiant ---");
                    System.out.print("ID de l’étudiant à supprimer : ");
                    int idSuppr;
                    try {
                        idSuppr = Integer.parseInt(sc.nextLine().trim());
                    } catch (NumberFormatException ex) {
                        System.out.println("ID invalide.");
                        break;
                    }

                    if (!etudiantDAO.existeEtudiant(idSuppr)) {
                        System.out.println("❌ Aucun étudiant avec l’ID " + idSuppr);
                        break;
                    }

                    boolean supprime = etudiantDAO.supprimerEtudiant(idSuppr);
                    if (supprime) {
                        System.out.println("✅ Étudiant supprimé.");
                    } else {
                        System.out.println("❌ Échec de la suppression. Vérifiez les inscriptions liées.");
                    }
                    break;

                case 0:
                    System.out.println("Au revoir !");
                    sc.close();
                    fermer(conn);
                    return;

                default:
                    System.out.println("Choix invalide.");
            }
            System.out.println();
        }
    }

    private static void fermer(Connection conn) {
        try { conn.close(); } catch (Exception ignored) {}
    }
}
