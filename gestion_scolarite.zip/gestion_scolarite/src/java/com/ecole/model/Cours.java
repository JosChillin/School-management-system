package com.ecole.model;

// Classe "Cours" qui représente la table SQL "cours"
public class Cours 
{
    private int id;
    private String nomCours; // correspond à nom_cours en SQL
    private int credits;     // correspond à credits en SQL

    public Cours(int id, String nomCours, int credits) {
        this.id = id;
        this.nomCours = nomCours;
        this.credits = credits;
    }

    // Getters
    public int getId() { return id; }
    public String getNomCours() { return nomCours; }
    public int getCredits() { return credits; }
}
