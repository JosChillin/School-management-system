package com.ecole.model;

// Classe "Etudiant" qui représente la table SQL "etudiants"
public class Etudiant 
{
    // Attributs privés (encapsulation)
    private int id;
    private String nom;
    private String prenom;
    private String dateNaissance; // correspond à la colonne DATE en SQL

    // Constructeur : initialise un objet Etudiant
    public Etudiant(int id, String nom, String prenom, String dateNaissance) {
        this.id = id;
        this.nom = nom;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
    }

    // Getters : permettent d'accéder aux attributs
    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getPrenom() { return prenom; }
    public String getDateNaissance() { return dateNaissance; }
}
