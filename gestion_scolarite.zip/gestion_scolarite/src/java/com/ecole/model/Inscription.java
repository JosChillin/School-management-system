package com.ecole.model;

import java.sql.Date;

/**
 * Classe "Inscription" qui représente une liaison entre un étudiant et un cours.
 * Utilisée pour les vues globales, les inscriptions par cours, et les cours par étudiant.
 */
public class Inscription {
    private int idInscription;
    private int etudiantId;
    private String nomEtudiant;
    private String prenomEtudiant;
    private int coursId;
    private String nomCours;
    private Date dateNaissance; // utilisé uniquement dans certaines vues

    // Constructeur complet avec date de naissance
    public Inscription(int idInscription, int etudiantId, String nomEtudiant, String prenomEtudiant,
                       int coursId, String nomCours, Date dateNaissance) {
        this.idInscription = idInscription;
        this.etudiantId = etudiantId;
        this.nomEtudiant = nomEtudiant;
        this.prenomEtudiant = prenomEtudiant;
        this.coursId = coursId;
        this.nomCours = nomCours;
        this.dateNaissance = dateNaissance;
    }

    // Constructeur sans date de naissance
    public Inscription(int idInscription, int etudiantId, String nomEtudiant, String prenomEtudiant,
                       int coursId, String nomCours) {
        this(idInscription, etudiantId, nomEtudiant, prenomEtudiant, coursId, nomCours, null);
    }

    // Constructeur minimal (utilisé pour l'ajout)
    public Inscription(int etudiantId, int coursId) {
        this.etudiantId = etudiantId;
        this.coursId = coursId;
    }

    // Getters
    public int getIdInscription() { return idInscription; }
    public int getEtudiantId() { return etudiantId; }
    public String getNomEtudiant() { return nomEtudiant; }
    public String getPrenomEtudiant() { return prenomEtudiant; }
    public int getCoursId() { return coursId; }
    public String getNomCours() { return nomCours; }
    public Date getDateNaissance() { return dateNaissance; }

    // Setters (optionnels si tu veux rendre l'objet modifiable)
    public void setIdInscription(int idInscription) { this.idInscription = idInscription; }
    public void setEtudiantId(int etudiantId) { this.etudiantId = etudiantId; }
    public void setNomEtudiant(String nomEtudiant) { this.nomEtudiant = nomEtudiant; }
    public void setPrenomEtudiant(String prenomEtudiant) { this.prenomEtudiant = prenomEtudiant; }
    public void setCoursId(int coursId) { this.coursId = coursId; }
    public void setNomCours(String nomCours) { this.nomCours = nomCours; }
    public void setDateNaissance(Date dateNaissance) { this.dateNaissance = dateNaissance; }
}
