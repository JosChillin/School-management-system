package com.ecole.dao;

import com.ecole.model.Inscription;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InscriptionDAO {

    // Ajouter une inscription (avec vérification de doublon)
    public boolean ajouterInscription(Inscription i) {
        String checkSql = "SELECT COUNT(*) FROM inscriptions WHERE etudiant_id = ? AND cours_id = ?";
        String insertSql = "INSERT INTO inscriptions(etudiant_id, cours_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement check = conn.prepareStatement(checkSql);
             PreparedStatement insert = conn.prepareStatement(insertSql)) {

            check.setInt(1, i.getEtudiantId());
            check.setInt(2, i.getCoursId());
            ResultSet rs = check.executeQuery();
            rs.next();
            if (rs.getInt(1) > 0) {
                System.out.println("ℹ️ Inscription déjà existante pour cet étudiant et ce cours.");
                return false;
            }

            insert.setInt(1, i.getEtudiantId());
            insert.setInt(2, i.getCoursId());
            int rows = insert.executeUpdate();
            return rows == 1;

        } catch (SQLException ex) {
            System.out.println("❌ Impossible d'ajouter l'inscription : " + ex.getMessage());
            return false;
        }
    }

    // Lister toutes les inscriptions (vue globale)
    public List<Inscription> listerInscriptions() {
        List<Inscription> inscriptions = new ArrayList<>();
        String sql = """
            SELECT i.id AS id_inscription,
                   e.id AS etudiant_id, e.nom, e.prenom,
                   c.id AS cours_id, c.nom_cours
            FROM inscriptions i
            JOIN etudiants e ON i.etudiant_id = e.id
            JOIN cours c ON i.cours_id = c.id
            ORDER BY i.id
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Inscription ins = new Inscription(
                    rs.getInt("id_inscription"),
                    rs.getInt("etudiant_id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("cours_id"),
                    rs.getString("nom_cours")
                );
                inscriptions.add(ins);
            }

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de lister les inscriptions : " + ex.getMessage());
        }
        return inscriptions;
    }

    // Lister les étudiants inscrits à un cours donné
    public List<Inscription> listerEtudiantsParCours(int coursId) {
        List<Inscription> resultats = new ArrayList<>();
        String sql = """
            SELECT i.id AS id_inscription,
                   e.id AS etudiant_id, e.nom, e.prenom, e.date_naissance,
                   c.nom_cours
            FROM inscriptions i
            JOIN etudiants e ON i.etudiant_id = e.id
            JOIN cours c ON i.cours_id = c.id
            WHERE i.cours_id = ?
            ORDER BY e.nom, e.prenom
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, coursId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Inscription ins = new Inscription(
                    rs.getInt("id_inscription"),
                    rs.getInt("etudiant_id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    coursId,
                    rs.getString("nom_cours"),
                    rs.getDate("date_naissance") // champ supplémentaire
                );
                resultats.add(ins);
            }

        } catch (SQLException ex) {
            System.out.println("❌ Erreur lors de la récupération des étudiants du cours : " + ex.getMessage());
        }

        return resultats;
    }

    // Supprimer une inscription (par étudiant et cours)
    public boolean supprimerInscription(int etudiantId, int coursId) {
        String sql = "DELETE FROM inscriptions WHERE etudiant_id = ? AND cours_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, etudiantId);
            stmt.setInt(2, coursId);
            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de supprimer l'inscription : " + ex.getMessage());
            return false;
        }
    }

    // Lister les cours d’un étudiant
    public List<Inscription> listerCoursParEtudiant(int etudiantId) {
        List<Inscription> resultats = new ArrayList<>();
        String sql = """
            SELECT i.id AS id_inscription,
                   c.id AS cours_id, c.nom_cours, c.credits,
                   e.id AS etudiant_id, e.nom, e.prenom
            FROM inscriptions i
            JOIN cours c ON i.cours_id = c.id
            JOIN etudiants e ON i.etudiant_id = e.id
            WHERE i.etudiant_id = ?
            ORDER BY c.nom_cours
        """;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, etudiantId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Inscription ins = new Inscription(
                    rs.getInt("id_inscription"),
                    rs.getInt("etudiant_id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("cours_id"),
                    rs.getString("nom_cours")
                );
                resultats.add(ins);
            }

        } catch (SQLException ex) {
            System.out.println("❌ Erreur lors de la récupération des cours de l'étudiant : " + ex.getMessage());
        }

        return resultats;
    }
}
