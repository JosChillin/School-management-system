package com.ecole.dao;

import com.ecole.model.Etudiant;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EtudiantDAO {

    // Ajouter un étudiant
    public void ajouterEtudiant(Etudiant e) {
        String sql = "INSERT INTO etudiants(nom, prenom, date_naissance) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, e.getNom());
            stmt.setString(2, e.getPrenom());
            stmt.setString(3, e.getDateNaissance());
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("❌ Impossible d'ajouter l'étudiant : " + ex.getMessage());
        }
    }

    // Vérifier si un étudiant existe
    public boolean existeEtudiant(int id) {
        String sql = "SELECT COUNT(*) FROM etudiants WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException ex) {
            System.out.println("❌ Erreur lors de la vérification de l’étudiant : " + ex.getMessage());
            return false;
        }
    }

    // Lister tous les étudiants
    public List<Etudiant> listerEtudiants() {
        List<Etudiant> etudiants = new ArrayList<>();
        String sql = "SELECT * FROM etudiants";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                etudiants.add(new Etudiant(
                    rs.getInt("id"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("date_naissance")
                ));
            }

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de lister les étudiants : " + ex.getMessage());
        }
        return etudiants;
    }

    // Mettre à jour un étudiant (nom, prénom, date de naissance)
    public boolean mettreAJourEtudiant(int id, String nouveauNom, String nouveauPrenom, String nouvelleDateNaissance) {
        String sql = "UPDATE etudiants SET nom = ?, prenom = ?, date_naissance = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nouveauNom);
            stmt.setString(2, nouveauPrenom);
            stmt.setString(3, nouvelleDateNaissance);
            stmt.setInt(4, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException ex) {
            System.out.println("❌ Échec de la mise à jour de l’étudiant : " + ex.getMessage());
            return false;
        }
    }

    // Supprimer un étudiant
    public boolean supprimerEtudiant(int id) {
        String sql = "DELETE FROM etudiants WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de supprimer l’étudiant : " + ex.getMessage());
            return false;
        }
    }
}
