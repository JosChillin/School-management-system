package com.ecole.dao;

import com.ecole.model.Cours;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CoursDAO {

    // Ajouter un cours
    public void ajouterCours(Cours c) {
        String sql = "INSERT INTO cours(nom_cours, credits) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, c.getNomCours());
            stmt.setInt(2, c.getCredits());
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("❌ Impossible d'ajouter le cours : " + ex.getMessage());
        }
    }

    // Vérifier si un cours existe
    public boolean existeCours(int id) {
        String sql = "SELECT COUNT(*) FROM cours WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException ex) {
            System.out.println("❌ Erreur lors de la vérification du cours : " + ex.getMessage());
            return false;
        }
    }

    // Lister tous les cours
    public List<Cours> listerCours() {
        List<Cours> cours = new ArrayList<>();
        String sql = "SELECT * FROM cours";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                cours.add(new Cours(
                    rs.getInt("id"),
                    rs.getString("nom_cours"),
                    rs.getInt("credits")
                ));
            }

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de lister les cours : " + ex.getMessage());
        }
        return cours;
    }

    // Mettre à jour un cours
    public boolean mettreAJourCours(int id, String nouveauNom, int nouveauxCredits) {
        String sql = "UPDATE cours SET nom_cours = ?, credits = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nouveauNom);
            stmt.setInt(2, nouveauxCredits);
            stmt.setInt(3, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException ex) {
            System.out.println("❌ Échec de la mise à jour du cours : " + ex.getMessage());
            return false;
        }
    }

    // Supprimer un cours
    public boolean supprimerCours(int id) {
        String sql = "DELETE FROM cours WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;

        } catch (SQLException ex) {
            System.out.println("❌ Impossible de supprimer le cours : " + ex.getMessage());
            return false;
        }
    }
}
