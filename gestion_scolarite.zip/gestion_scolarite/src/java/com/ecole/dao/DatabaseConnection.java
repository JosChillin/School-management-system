package com.ecole.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe utilitaire qui gère la connexion JDBC à MySQL.
 * Les identifiants de connexion (URL, utilisateur, mot de passe)
 * sont fournis dynamiquement via la méthode init().
 */
public class DatabaseConnection 
{

    // Variables de connexion (initialisées dynamiquement)
    private static String url;
    private static String user;
    private static String password;

    /**
     * Initialise les paramètres de connexion à la base de données.
     * Cette méthode doit être appelée une fois au démarrage du programme.
     *
     * @param u    URL JDBC complète (ex: jdbc:mysql://localhost:3306/gestion_scolarite)
     * @param usr  Nom d'utilisateur MySQL
     * @param pwd  Mot de passe MySQL
     */
    public static void init(String u, String usr, String pwd) {
        url = u;
        user = usr;
        password = pwd;
    }

    /**
     * Retourne une connexion JDBC active à la base MySQL.
     * Utilise les paramètres fournis via init().
     *
     * @return Connection JDBC
     * @throws SQLException si la connexion échoue
     */
    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.err.println("❌ Erreur de connexion à la base : " + e.getMessage());
            throw e;
        }
    }
}
